import React from "react";
import "../common/footer.css"

function Footer(){
    return(
        <>
        <div className="text-center mt-4">
            <span className="text-center text-[14px] footer_txt">
                Lemosys@ <span className="underline"> copywrite@2022</span>
            </span>
        </div>
        </>
    )
}
export default Footer;