import React from 'react'

export const sidebar = () => {
  return (
    <div>data</div>
  )
}
