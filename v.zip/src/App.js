import './App.css';
import Navbar from './components/common/Sidebar';
import Dashboard from './components/dashboard/Dashboard';
import Membership from './components/membership/Membership';
import Profile from './components/profile/Profile';

function App() {
  return (
    <div>
     {/* <LogIn/> */}
    {/* <Navbar/> */}
  {/* <Profile/> */}
  {/* <Membership/> */}
  <Dashboard/>
    </div>
  );
}

export default App;
